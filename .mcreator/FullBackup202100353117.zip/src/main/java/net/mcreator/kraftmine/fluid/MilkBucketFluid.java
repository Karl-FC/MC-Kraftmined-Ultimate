
package net.mcreator.kraftmine.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.fluids.FluidAttributes;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.kraftmine.init.KraftmineModFluids;
import net.mcreator.kraftmine.init.KraftmineModBlocks;

public abstract class MilkBucketFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> KraftmineModFluids.MILK_BUCKET,
			() -> KraftmineModFluids.FLOWING_MILK_BUCKET,
			FluidAttributes.builder(new ResourceLocation("kraftmine:blocks/milkstill"), new ResourceLocation("kraftmine:blocks/milkflow"))

	).explosionResistance(100f)

			.tickRate(6)

			.block(() -> (LiquidBlock) KraftmineModBlocks.MILK_BUCKET);

	private MilkBucketFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.DRIPPING_WATER;
	}

	public static class Source extends MilkBucketFluid {
		public Source() {
			super();
			setRegistryName("milk_bucket");
		}

		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends MilkBucketFluid {
		public Flowing() {
			super();
			setRegistryName("flowing_milk_bucket");
		}

		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
