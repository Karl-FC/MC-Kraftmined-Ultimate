
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kraftmine.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.kraftmine.block.WallnutBlock;
import net.mcreator.kraftmine.block.TungstenOreBlock;
import net.mcreator.kraftmine.block.TungstenBlockBlock;
import net.mcreator.kraftmine.block.PalmWoodWoodBlock;
import net.mcreator.kraftmine.block.PalmWoodStairsBlock;
import net.mcreator.kraftmine.block.PalmWoodSlabBlock;
import net.mcreator.kraftmine.block.PalmWoodPressurePlateBlock;
import net.mcreator.kraftmine.block.PalmWoodPlanksBlock;
import net.mcreator.kraftmine.block.PalmWoodLogBlock;
import net.mcreator.kraftmine.block.PalmWoodLeavesBlock;
import net.mcreator.kraftmine.block.PalmWoodFenceGateBlock;
import net.mcreator.kraftmine.block.PalmWoodFenceBlock;
import net.mcreator.kraftmine.block.PalmWoodButtonBlock;
import net.mcreator.kraftmine.block.MilkBucketBlock;
import net.mcreator.kraftmine.block.MahoganyWoodBlock;
import net.mcreator.kraftmine.block.MahoganyStairsBlock;
import net.mcreator.kraftmine.block.MahoganySlabBlock;
import net.mcreator.kraftmine.block.MahoganyPressurePlateBlock;
import net.mcreator.kraftmine.block.MahoganyPlanksBlock;
import net.mcreator.kraftmine.block.MahoganyLogBlock;
import net.mcreator.kraftmine.block.MahoganyLeavesBlock;
import net.mcreator.kraftmine.block.MahoganyFenceGateBlock;
import net.mcreator.kraftmine.block.MahoganyFenceBlock;
import net.mcreator.kraftmine.block.MahoganyButtonBlock;
import net.mcreator.kraftmine.block.LegoBlockBlock;
import net.mcreator.kraftmine.block.CloudBlockRainBlock;
import net.mcreator.kraftmine.block.CloudBlock;
import net.mcreator.kraftmine.block.CherryWoodBlock;
import net.mcreator.kraftmine.block.CherryStairsBlock;
import net.mcreator.kraftmine.block.CherrySlabBlock;
import net.mcreator.kraftmine.block.CherryPressurePlateBlock;
import net.mcreator.kraftmine.block.CherryPlanksBlock;
import net.mcreator.kraftmine.block.CherryLogBlock;
import net.mcreator.kraftmine.block.CherryLeavesBlock;
import net.mcreator.kraftmine.block.CherryFenceGateBlock;
import net.mcreator.kraftmine.block.CherryFenceBlock;
import net.mcreator.kraftmine.block.CherryButtonBlock;
import net.mcreator.kraftmine.block.BambooStairsBlock;
import net.mcreator.kraftmine.block.BambooSlabBlock;
import net.mcreator.kraftmine.block.BambooPressurePlateBlock;
import net.mcreator.kraftmine.block.BambooPlanksBlock;
import net.mcreator.kraftmine.block.BambooFenceGateBlock;
import net.mcreator.kraftmine.block.BambooFenceBlock;
import net.mcreator.kraftmine.block.BambooButtonBlock;
import net.mcreator.kraftmine.block.AppleblockBlock;
import net.mcreator.kraftmine.block.AetherDimensionPortalBlock;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class KraftmineModBlocks {
	private static final List<Block> REGISTRY = new ArrayList<>();
	public static final Block MAHOGANY_WOOD = register(new MahoganyWoodBlock());
	public static final Block MAHOGANY_LOG = register(new MahoganyLogBlock());
	public static final Block MAHOGANY_PLANKS = register(new MahoganyPlanksBlock());
	public static final Block MAHOGANY_LEAVES = register(new MahoganyLeavesBlock());
	public static final Block MAHOGANY_STAIRS = register(new MahoganyStairsBlock());
	public static final Block MAHOGANY_SLAB = register(new MahoganySlabBlock());
	public static final Block MAHOGANY_FENCE = register(new MahoganyFenceBlock());
	public static final Block MAHOGANY_FENCE_GATE = register(new MahoganyFenceGateBlock());
	public static final Block MAHOGANY_PRESSURE_PLATE = register(new MahoganyPressurePlateBlock());
	public static final Block MAHOGANY_BUTTON = register(new MahoganyButtonBlock());
	public static final Block CHERRY_WOOD = register(new CherryWoodBlock());
	public static final Block CHERRY_LOG = register(new CherryLogBlock());
	public static final Block CHERRY_PLANKS = register(new CherryPlanksBlock());
	public static final Block CHERRY_LEAVES = register(new CherryLeavesBlock());
	public static final Block CHERRY_STAIRS = register(new CherryStairsBlock());
	public static final Block CHERRY_SLAB = register(new CherrySlabBlock());
	public static final Block CHERRY_FENCE_GATE = register(new CherryFenceGateBlock());
	public static final Block CHERRY_BUTTON = register(new CherryButtonBlock());
	public static final Block PALM_WOOD_WOOD = register(new PalmWoodWoodBlock());
	public static final Block PALM_WOOD_LOG = register(new PalmWoodLogBlock());
	public static final Block PALM_WOOD_PLANKS = register(new PalmWoodPlanksBlock());
	public static final Block PALM_WOOD_LEAVES = register(new PalmWoodLeavesBlock());
	public static final Block PALM_WOOD_STAIRS = register(new PalmWoodStairsBlock());
	public static final Block PALM_WOOD_SLAB = register(new PalmWoodSlabBlock());
	public static final Block PALM_WOOD_FENCE = register(new PalmWoodFenceBlock());
	public static final Block PALM_WOOD_PRESSURE_PLATE = register(new PalmWoodPressurePlateBlock());
	public static final Block PALM_WOOD_BUTTON = register(new PalmWoodButtonBlock());
	public static final Block BAMBOO_PLANKS = register(new BambooPlanksBlock());
	public static final Block BAMBOO_STAIRS = register(new BambooStairsBlock());
	public static final Block BAMBOO_SLAB = register(new BambooSlabBlock());
	public static final Block BAMBOO_FENCE = register(new BambooFenceBlock());
	public static final Block BAMBOO_FENCE_GATE = register(new BambooFenceGateBlock());
	public static final Block BAMBOO_PRESSURE_PLATE = register(new BambooPressurePlateBlock());
	public static final Block BAMBOO_BUTTON = register(new BambooButtonBlock());
	public static final Block APPLEBLOCK = register(new AppleblockBlock());
	public static final Block TUNGSTEN_ORE = register(new TungstenOreBlock());
	public static final Block TUNGSTEN_BLOCK = register(new TungstenBlockBlock());
	public static final Block CLOUD = register(new CloudBlock());
	public static final Block CLOUD_BLOCK_RAIN = register(new CloudBlockRainBlock());
	public static final Block LEGO_BLOCK = register(new LegoBlockBlock());
	public static final Block AETHER_DIMENSION_PORTAL = register(new AetherDimensionPortalBlock());
	public static final Block MILK_BUCKET = register(new MilkBucketBlock());
	public static final Block CHERRY_FENCE = register(new CherryFenceBlock());
	public static final Block CHERRY_PRESSURE_PLATE = register(new CherryPressurePlateBlock());
	public static final Block PALM_WOOD_FENCE_GATE = register(new PalmWoodFenceGateBlock());
	public static final Block WALLNUT = register(new WallnutBlock());

	private static Block register(Block block) {
		REGISTRY.add(block);
		return block;
	}

	@SubscribeEvent
	public static void registerBlocks(RegistryEvent.Register<Block> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Block[0]));
	}

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			LegoBlockBlock.registerRenderLayer();
		}
	}
}
