
package net.mcreator.kraftmine.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.kraftmine.init.KraftmineModTabs;

public class CrystalDarkItem extends Item {
	public CrystalDarkItem() {
		super(new Item.Properties().tab(KraftmineModTabs.TAB_CRTAB).stacksTo(64).rarity(Rarity.EPIC));
		setRegistryName("crystal_dark");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
