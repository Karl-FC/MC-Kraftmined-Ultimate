
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kraftmine.init;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.biome.Biome;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.kraftmine.world.biome.WastelandBiome;
import net.mcreator.kraftmine.world.biome.TropicsBiome;
import net.mcreator.kraftmine.world.biome.SakuraBiome;
import net.mcreator.kraftmine.world.biome.RobloxBiome;
import net.mcreator.kraftmine.world.biome.EerieBiome;
import net.mcreator.kraftmine.world.biome.DomainBiome;
import net.mcreator.kraftmine.world.biome.AetherBiomeBiome;
import net.mcreator.kraftmine.KraftmineMod;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class KraftmineModBiomes {
	private static final List<Biome> REGISTRY = new ArrayList<>();
	public static Biome AETHER_BIOME = register("aether_biome", AetherBiomeBiome.createBiome());
	public static Biome WASTELAND = register("wasteland", WastelandBiome.createBiome());
	public static Biome EERIE = register("eerie", EerieBiome.createBiome());
	public static Biome SAKURA = register("sakura", SakuraBiome.createBiome());
	public static Biome ROBLOX = register("roblox", RobloxBiome.createBiome());
	public static Biome DOMAIN = register("domain", DomainBiome.createBiome());
	public static Biome TROPICS = register("tropics", TropicsBiome.createBiome());

	private static Biome register(String registryname, Biome biome) {
		REGISTRY.add(biome.setRegistryName(new ResourceLocation(KraftmineMod.MODID, registryname)));
		return biome;
	}

	@SubscribeEvent
	public static void registerBiomes(RegistryEvent.Register<Biome> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Biome[0]));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			AetherBiomeBiome.init();
			WastelandBiome.init();
			EerieBiome.init();
			SakuraBiome.init();
			RobloxBiome.init();
			DomainBiome.init();
			TropicsBiome.init();
		});
	}
}
