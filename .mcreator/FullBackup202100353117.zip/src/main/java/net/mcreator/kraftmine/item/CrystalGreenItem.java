
package net.mcreator.kraftmine.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.kraftmine.init.KraftmineModTabs;

public class CrystalGreenItem extends Item {
	public CrystalGreenItem() {
		super(new Item.Properties().tab(KraftmineModTabs.TAB_CRTAB).stacksTo(64).rarity(Rarity.RARE));
		setRegistryName("crystal_green");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
