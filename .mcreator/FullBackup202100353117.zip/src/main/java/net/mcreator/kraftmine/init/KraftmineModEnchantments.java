
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kraftmine.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.kraftmine.enchantment.SaberSwingEnchantment;
import net.mcreator.kraftmine.enchantment.LifestealEnchantment;
import net.mcreator.kraftmine.enchantment.BaneofMetapodEnchantment;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class KraftmineModEnchantments {
	private static final List<Enchantment> REGISTRY = new ArrayList<>();
	public static final Enchantment SABER_SWING = register("kraftmine:saber_swing", new SaberSwingEnchantment());
	public static final Enchantment BANEOF_METAPOD = register("kraftmine:baneof_metapod", new BaneofMetapodEnchantment());
	public static final Enchantment LIFESTEAL = register("kraftmine:lifesteal", new LifestealEnchantment());

	private static Enchantment register(String registryname, Enchantment enchantment) {
		REGISTRY.add(enchantment.setRegistryName(registryname));
		return enchantment;
	}

	@SubscribeEvent
	public static void registerEnchantments(RegistryEvent.Register<Enchantment> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Enchantment[0]));
	}
}
