
package net.mcreator.kraftmine.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

import net.mcreator.kraftmine.init.KraftmineModTabs;

public class CornItem extends Item {
	public CornItem() {
		super(new Item.Properties().tab(KraftmineModTabs.TAB_CRTAB).stacksTo(64).rarity(Rarity.COMMON)
				.food((new FoodProperties.Builder()).nutrition(6).saturationMod(0.1f)

						.build()));
		setRegistryName("corn");
	}

	@Override
	public int getUseDuration(ItemStack stack) {
		return 300;
	}
}
