package net.mcreator.kraftmine.procedures;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.kraftmine.init.KraftmineModItems;

public class ChaliceCupRightClickProcedure {
	public static void execute(BlockState blockstate, Entity entity) {
		if (entity == null)
			return;
		if (blockstate.getMaterial() == net.minecraft.world.level.material.Material.WATER
				|| blockstate.getBlock() instanceof LiquidBlock && !(blockstate.getMaterial() == net.minecraft.world.level.material.Material.LAVA)) {
			if (entity instanceof Player _player) {
				ItemStack _setstack = new ItemStack(KraftmineModItems.WATER_GOLD);
				_setstack.setCount(1);
				ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
			}
			if (entity instanceof Player _player) {
				ItemStack _stktoremove = new ItemStack(KraftmineModItems.CHALICE);
				_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1,
						_player.inventoryMenu.getCraftSlots());
			}
		}
	}
}
