
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kraftmine.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import java.util.Map;
import java.util.HashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class KraftmineModSounds {
	public static Map<ResourceLocation, SoundEvent> REGISTRY = new HashMap<>();
	static {
		REGISTRY.put(new ResourceLocation("kraftmine", "sirenhead.death"), new SoundEvent(new ResourceLocation("kraftmine", "sirenhead.death")));
		REGISTRY.put(new ResourceLocation("kraftmine", "sirenhead.hurt"), new SoundEvent(new ResourceLocation("kraftmine", "sirenhead.hurt")));
		REGISTRY.put(new ResourceLocation("kraftmine", "sirenhead.idle"), new SoundEvent(new ResourceLocation("kraftmine", "sirenhead.idle")));
		REGISTRY.put(new ResourceLocation("kraftmine", "goose.honk"), new SoundEvent(new ResourceLocation("kraftmine", "goose.honk")));
		REGISTRY.put(new ResourceLocation("kraftmine", "horror.jumpscare.short"),
				new SoundEvent(new ResourceLocation("kraftmine", "horror.jumpscare.short")));
		REGISTRY.put(new ResourceLocation("kraftmine", "horror.jumpscare.lol"),
				new SoundEvent(new ResourceLocation("kraftmine", "horror.jumpscare.lol")));
		REGISTRY.put(new ResourceLocation("kraftmine", "horror.jumpscare.criminal"),
				new SoundEvent(new ResourceLocation("kraftmine", "horror.jumpscare.criminal")));
		REGISTRY.put(new ResourceLocation("kraftmine", "horror.jumpscare.med"),
				new SoundEvent(new ResourceLocation("kraftmine", "horror.jumpscare.med")));
		REGISTRY.put(new ResourceLocation("kraftmine", "horror.jumpscare.long"),
				new SoundEvent(new ResourceLocation("kraftmine", "horror.jumpscare.long")));
		REGISTRY.put(new ResourceLocation("kraftmine", "mickey.idle"), new SoundEvent(new ResourceLocation("kraftmine", "mickey.idle")));
		REGISTRY.put(new ResourceLocation("kraftmine", "mickey.death"), new SoundEvent(new ResourceLocation("kraftmine", "mickey.death")));
		REGISTRY.put(new ResourceLocation("kraftmine", "mickey.hurt"), new SoundEvent(new ResourceLocation("kraftmine", "mickey.hurt")));
		REGISTRY.put(new ResourceLocation("kraftmine", "theme.aot"), new SoundEvent(new ResourceLocation("kraftmine", "theme.aot")));
		REGISTRY.put(new ResourceLocation("kraftmine", "travel.aether"), new SoundEvent(new ResourceLocation("kraftmine", "travel.aether")));
	}

	@SubscribeEvent
	public static void registerSounds(RegistryEvent.Register<SoundEvent> event) {
		for (Map.Entry<ResourceLocation, SoundEvent> sound : REGISTRY.entrySet())
			event.getRegistry().register(sound.getValue().setRegistryName(sound.getKey()));
	}
}
