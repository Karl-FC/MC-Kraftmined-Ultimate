
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kraftmine.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.kraftmine.client.model.Modelsirenhead;
import net.mcreator.kraftmine.client.model.Modelrazor;
import net.mcreator.kraftmine.client.model.Modelbod;
import net.mcreator.kraftmine.client.model.ModelMimic;
import net.mcreator.kraftmine.client.model.ModelMickey;
import net.mcreator.kraftmine.client.model.ModelGoose;
import net.mcreator.kraftmine.client.model.ModelGiant_ai;
import net.mcreator.kraftmine.client.model.ModelGhostSpider;
import net.mcreator.kraftmine.client.model.ModelAmogus;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class KraftmineModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelrazor.LAYER_LOCATION, Modelrazor::createBodyLayer);
		event.registerLayerDefinition(ModelGoose.LAYER_LOCATION, ModelGoose::createBodyLayer);
		event.registerLayerDefinition(ModelGhostSpider.LAYER_LOCATION, ModelGhostSpider::createBodyLayer);
		event.registerLayerDefinition(ModelMickey.LAYER_LOCATION, ModelMickey::createBodyLayer);
		event.registerLayerDefinition(Modelbod.LAYER_LOCATION, Modelbod::createBodyLayer);
		event.registerLayerDefinition(ModelGiant_ai.LAYER_LOCATION, ModelGiant_ai::createBodyLayer);
		event.registerLayerDefinition(ModelAmogus.LAYER_LOCATION, ModelAmogus::createBodyLayer);
		event.registerLayerDefinition(ModelMimic.LAYER_LOCATION, ModelMimic::createBodyLayer);
		event.registerLayerDefinition(Modelsirenhead.LAYER_LOCATION, Modelsirenhead::createBodyLayer);
	}
}
