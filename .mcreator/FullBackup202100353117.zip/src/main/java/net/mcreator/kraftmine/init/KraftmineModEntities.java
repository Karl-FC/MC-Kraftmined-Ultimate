
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kraftmine.init;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.kraftmine.entity.SirenheadEntity;
import net.mcreator.kraftmine.entity.RangedTomatoEntity;
import net.mcreator.kraftmine.entity.MobAmogusEntity;
import net.mcreator.kraftmine.entity.MimicEntityEntity;
import net.mcreator.kraftmine.entity.MickeyEntity;
import net.mcreator.kraftmine.entity.GooseEntity;
import net.mcreator.kraftmine.entity.GiantAIEntity;
import net.mcreator.kraftmine.entity.GhostSpiderEntity;
import net.mcreator.kraftmine.entity.EntityBodEntity;
import net.mcreator.kraftmine.entity.BladeRazorEntity;
import net.mcreator.kraftmine.entity.BladeOfDespairEntity;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class KraftmineModEntities {
	private static final List<EntityType<?>> REGISTRY = new ArrayList<>();
	public static final EntityType<RangedTomatoEntity> RANGED_TOMATO = register("entitybulletranged_tomato",
			EntityType.Builder.<RangedTomatoEntity>of(RangedTomatoEntity::new, MobCategory.MISC).setCustomClientFactory(RangedTomatoEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<BladeRazorEntity> BLADE_RAZOR = register("entitybulletblade_razor",
			EntityType.Builder.<BladeRazorEntity>of(BladeRazorEntity::new, MobCategory.MISC).setCustomClientFactory(BladeRazorEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<BladeOfDespairEntity> BLADE_OF_DESPAIR = register("entitybulletblade_of_despair",
			EntityType.Builder.<BladeOfDespairEntity>of(BladeOfDespairEntity::new, MobCategory.MISC).setCustomClientFactory(BladeOfDespairEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<GooseEntity> GOOSE = register("goose",
			EntityType.Builder.<GooseEntity>of(GooseEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(GooseEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final EntityType<GhostSpiderEntity> GHOST_SPIDER = register("ghost_spider",
			EntityType.Builder.<GhostSpiderEntity>of(GhostSpiderEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(GhostSpiderEntity::new).sized(1.6f, 1.2000000000000002f));
	public static final EntityType<MimicEntityEntity> MIMIC_ENTITY = register("mimic_entity",
			EntityType.Builder.<MimicEntityEntity>of(MimicEntityEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(MimicEntityEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final EntityType<MickeyEntity> MICKEY = register("mickey", EntityType.Builder.<MickeyEntity>of(MickeyEntity::new, MobCategory.MISC)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(MickeyEntity::new).sized(1f, 3f));
	public static final EntityType<MobAmogusEntity> MOB_AMOGUS = register("mob_amogus",
			EntityType.Builder.<MobAmogusEntity>of(MobAmogusEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(MobAmogusEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<SirenheadEntity> SIRENHEAD = register("sirenhead",
			EntityType.Builder.<SirenheadEntity>of(SirenheadEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SirenheadEntity::new).sized(0.7f, 5f));
	public static final EntityType<GiantAIEntity> GIANT_AI = register("giant_ai",
			EntityType.Builder.<GiantAIEntity>of(GiantAIEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(GiantAIEntity::new).fireImmune().sized(0.5f, 10f));
	public static final EntityType<EntityBodEntity> ENTITY_BOD = register("entity_bod",
			EntityType.Builder.<EntityBodEntity>of(EntityBodEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(0).setUpdateInterval(3).setCustomClientFactory(EntityBodEntity::new).sized(0.5f, 1f));

	private static <T extends Entity> EntityType<T> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		EntityType<T> entityType = (EntityType<T>) entityTypeBuilder.build(registryname).setRegistryName(registryname);
		REGISTRY.add(entityType);
		return entityType;
	}

	@SubscribeEvent
	public static void registerEntities(RegistryEvent.Register<EntityType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new EntityType[0]));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			GooseEntity.init();
			GhostSpiderEntity.init();
			MimicEntityEntity.init();
			MickeyEntity.init();
			MobAmogusEntity.init();
			SirenheadEntity.init();
			GiantAIEntity.init();
			EntityBodEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(GOOSE, GooseEntity.createAttributes().build());
		event.put(GHOST_SPIDER, GhostSpiderEntity.createAttributes().build());
		event.put(MIMIC_ENTITY, MimicEntityEntity.createAttributes().build());
		event.put(MICKEY, MickeyEntity.createAttributes().build());
		event.put(MOB_AMOGUS, MobAmogusEntity.createAttributes().build());
		event.put(SIRENHEAD, SirenheadEntity.createAttributes().build());
		event.put(GIANT_AI, GiantAIEntity.createAttributes().build());
		event.put(ENTITY_BOD, EntityBodEntity.createAttributes().build());
	}
}
