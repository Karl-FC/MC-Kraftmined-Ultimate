
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kraftmine.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.kraftmine.potion.PotionCryMobEffect;
import net.mcreator.kraftmine.potion.JumpscareEffectMobEffect;
import net.mcreator.kraftmine.potion.HelicopterMobEffect;
import net.mcreator.kraftmine.potion.EyepatchOnEffectMobEffect;
import net.mcreator.kraftmine.potion.EyepatchOffEffectMobEffect;
import net.mcreator.kraftmine.potion.DripMobEffect;
import net.mcreator.kraftmine.potion.BleedEffectMobEffect;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class KraftmineModMobEffects {
	private static final List<MobEffect> REGISTRY = new ArrayList<>();
	public static final MobEffect POTION_CRY = register(new PotionCryMobEffect());
	public static final MobEffect DRIP = register(new DripMobEffect());
	public static final MobEffect JUMPSCARE_EFFECT = register(new JumpscareEffectMobEffect());
	public static final MobEffect BLEED_EFFECT = register(new BleedEffectMobEffect());
	public static final MobEffect EYEPATCH_OFF_EFFECT = register(new EyepatchOffEffectMobEffect());
	public static final MobEffect EYEPATCH_ON_EFFECT = register(new EyepatchOnEffectMobEffect());
	public static final MobEffect HELICOPTER = register(new HelicopterMobEffect());

	private static MobEffect register(MobEffect effect) {
		REGISTRY.add(effect);
		return effect;
	}

	@SubscribeEvent
	public static void registerMobEffects(RegistryEvent.Register<MobEffect> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new MobEffect[0]));
	}
}
