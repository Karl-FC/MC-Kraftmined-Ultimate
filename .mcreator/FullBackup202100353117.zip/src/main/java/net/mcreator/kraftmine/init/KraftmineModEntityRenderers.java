
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kraftmine.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.kraftmine.client.renderer.SirenheadRenderer;
import net.mcreator.kraftmine.client.renderer.MobAmogusRenderer;
import net.mcreator.kraftmine.client.renderer.MimicEntityRenderer;
import net.mcreator.kraftmine.client.renderer.MickeyRenderer;
import net.mcreator.kraftmine.client.renderer.GooseRenderer;
import net.mcreator.kraftmine.client.renderer.GiantAIRenderer;
import net.mcreator.kraftmine.client.renderer.GhostSpiderRenderer;
import net.mcreator.kraftmine.client.renderer.EntityBodRenderer;
import net.mcreator.kraftmine.client.renderer.BladeRazorRenderer;
import net.mcreator.kraftmine.client.renderer.BladeOfDespairRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class KraftmineModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(KraftmineModEntities.RANGED_TOMATO, ThrownItemRenderer::new);
		event.registerEntityRenderer(KraftmineModEntities.BLADE_RAZOR, BladeRazorRenderer::new);
		event.registerEntityRenderer(KraftmineModEntities.BLADE_OF_DESPAIR, BladeOfDespairRenderer::new);
		event.registerEntityRenderer(KraftmineModEntities.GOOSE, GooseRenderer::new);
		event.registerEntityRenderer(KraftmineModEntities.GHOST_SPIDER, GhostSpiderRenderer::new);
		event.registerEntityRenderer(KraftmineModEntities.MIMIC_ENTITY, MimicEntityRenderer::new);
		event.registerEntityRenderer(KraftmineModEntities.MICKEY, MickeyRenderer::new);
		event.registerEntityRenderer(KraftmineModEntities.MOB_AMOGUS, MobAmogusRenderer::new);
		event.registerEntityRenderer(KraftmineModEntities.SIRENHEAD, SirenheadRenderer::new);
		event.registerEntityRenderer(KraftmineModEntities.GIANT_AI, GiantAIRenderer::new);
		event.registerEntityRenderer(KraftmineModEntities.ENTITY_BOD, EntityBodRenderer::new);
	}
}
