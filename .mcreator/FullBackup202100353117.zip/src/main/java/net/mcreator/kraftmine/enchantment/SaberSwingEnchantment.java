
package net.mcreator.kraftmine.enchantment;

import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.EquipmentSlot;

import net.mcreator.kraftmine.init.KraftmineModItems;

public class SaberSwingEnchantment extends Enchantment {
	public SaberSwingEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.UNCOMMON, EnchantmentCategory.WEAPON, slots);
	}

	@Override
	public int getMaxLevel() {
		return 2;
	}

	@Override
	public boolean canApplyAtEnchantingTable(ItemStack stack) {
		if (stack.getItem() == KraftmineModItems.SABER_RED)
			return true;
		if (stack.getItem() == KraftmineModItems.DIAMONDSABER)
			return true;
		if (stack.getItem() == KraftmineModItems.SABER_WHITE)
			return true;
		if (stack.getItem() == KraftmineModItems.SABER_DARK)
			return true;
		if (stack.getItem() == KraftmineModItems.SABER_PURPLE)
			return true;
		if (stack.getItem() == KraftmineModItems.SABER_GREEN)
			return true;
		if (stack.getItem() == KraftmineModItems.SABER_ORANGE)
			return true;
		if (stack.getItem() == KraftmineModItems.SABER_YELLOW)
			return true;
		return false;
	}
}
