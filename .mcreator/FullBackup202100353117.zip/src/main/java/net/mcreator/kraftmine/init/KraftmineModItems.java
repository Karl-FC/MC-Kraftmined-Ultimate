
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kraftmine.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.kraftmine.item.WoodenCupItem;
import net.mcreator.kraftmine.item.WoodIngotItem;
import net.mcreator.kraftmine.item.WineGlassItem;
import net.mcreator.kraftmine.item.WaterGoldItem;
import net.mcreator.kraftmine.item.WaterCupMugItem;
import net.mcreator.kraftmine.item.WaterCupItem;
import net.mcreator.kraftmine.item.WaterCupGlassItem;
import net.mcreator.kraftmine.item.TungstenSwordItem;
import net.mcreator.kraftmine.item.TungstenSword0Item;
import net.mcreator.kraftmine.item.TungstenShovelItem;
import net.mcreator.kraftmine.item.TungstenPickaxeItem;
import net.mcreator.kraftmine.item.TungstenIngotItem;
import net.mcreator.kraftmine.item.TungstenHoeItem;
import net.mcreator.kraftmine.item.TungstenAxeItem;
import net.mcreator.kraftmine.item.TungstenArmorItem;
import net.mcreator.kraftmine.item.SaberYellowItem;
import net.mcreator.kraftmine.item.SaberWhiteItem;
import net.mcreator.kraftmine.item.SaberRedItem;
import net.mcreator.kraftmine.item.SaberPurpleItem;
import net.mcreator.kraftmine.item.SaberOrangeItem;
import net.mcreator.kraftmine.item.SaberGreenItem;
import net.mcreator.kraftmine.item.SaberDarkItem;
import net.mcreator.kraftmine.item.ReactorCoreLowItem;
import net.mcreator.kraftmine.item.ReactorCoreItem;
import net.mcreator.kraftmine.item.RangedTomatoItem;
import net.mcreator.kraftmine.item.PebbleItem;
import net.mcreator.kraftmine.item.ObsidianscrapItem;
import net.mcreator.kraftmine.item.ObsidianNuggetItem;
import net.mcreator.kraftmine.item.ObsidianArmorItem;
import net.mcreator.kraftmine.item.MugItem;
import net.mcreator.kraftmine.item.HuskClawItem;
import net.mcreator.kraftmine.item.FryingPanItem;
import net.mcreator.kraftmine.item.FoodMaterwelonItem;
import net.mcreator.kraftmine.item.EyepatchItem;
import net.mcreator.kraftmine.item.EnchantedflintandsteelItem;
import net.mcreator.kraftmine.item.DripArmorItem;
import net.mcreator.kraftmine.item.DiamondsaberItem;
import net.mcreator.kraftmine.item.CrystalredItem;
import net.mcreator.kraftmine.item.CrystalYellowItem;
import net.mcreator.kraftmine.item.CrystalWhiteItem;
import net.mcreator.kraftmine.item.CrystalPurpleItem;
import net.mcreator.kraftmine.item.CrystalOrangeItem;
import net.mcreator.kraftmine.item.CrystalGreenItem;
import net.mcreator.kraftmine.item.CrystalDarkItem;
import net.mcreator.kraftmine.item.CrystalBlueItem;
import net.mcreator.kraftmine.item.CornItem;
import net.mcreator.kraftmine.item.CherryItem;
import net.mcreator.kraftmine.item.ChaliceItem;
import net.mcreator.kraftmine.item.BladeRazorItem;
import net.mcreator.kraftmine.item.BladeOfDespairItem;
import net.mcreator.kraftmine.item.BambooSwordItem;
import net.mcreator.kraftmine.item.BambooShovelItem;
import net.mcreator.kraftmine.item.BambooPickaxeItem;
import net.mcreator.kraftmine.item.BambooHoeItem;
import net.mcreator.kraftmine.item.BambooAxeItem;
import net.mcreator.kraftmine.item.AetherDimensionItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class KraftmineModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item MAHOGANY_WOOD = register(KraftmineModBlocks.MAHOGANY_WOOD, KraftmineModTabs.TAB_CRTAB);
	public static final Item MAHOGANY_LOG = register(KraftmineModBlocks.MAHOGANY_LOG, KraftmineModTabs.TAB_CRTAB);
	public static final Item MAHOGANY_PLANKS = register(KraftmineModBlocks.MAHOGANY_PLANKS, KraftmineModTabs.TAB_CRTAB);
	public static final Item MAHOGANY_LEAVES = register(KraftmineModBlocks.MAHOGANY_LEAVES, KraftmineModTabs.TAB_CRTAB);
	public static final Item MAHOGANY_STAIRS = register(KraftmineModBlocks.MAHOGANY_STAIRS, KraftmineModTabs.TAB_CRTAB);
	public static final Item MAHOGANY_SLAB = register(KraftmineModBlocks.MAHOGANY_SLAB, KraftmineModTabs.TAB_CRTAB);
	public static final Item MAHOGANY_FENCE = register(KraftmineModBlocks.MAHOGANY_FENCE, KraftmineModTabs.TAB_CRTAB);
	public static final Item MAHOGANY_FENCE_GATE = register(KraftmineModBlocks.MAHOGANY_FENCE_GATE, KraftmineModTabs.TAB_CRTAB);
	public static final Item MAHOGANY_PRESSURE_PLATE = register(KraftmineModBlocks.MAHOGANY_PRESSURE_PLATE, KraftmineModTabs.TAB_CRTAB);
	public static final Item MAHOGANY_BUTTON = register(KraftmineModBlocks.MAHOGANY_BUTTON, KraftmineModTabs.TAB_CRTAB);
	public static final Item CHERRY_WOOD = register(KraftmineModBlocks.CHERRY_WOOD, KraftmineModTabs.TAB_CRTAB);
	public static final Item CHERRY_LOG = register(KraftmineModBlocks.CHERRY_LOG, KraftmineModTabs.TAB_CRTAB);
	public static final Item CHERRY_PLANKS = register(KraftmineModBlocks.CHERRY_PLANKS, KraftmineModTabs.TAB_CRTAB);
	public static final Item CHERRY_LEAVES = register(KraftmineModBlocks.CHERRY_LEAVES, KraftmineModTabs.TAB_CRTAB);
	public static final Item CHERRY_STAIRS = register(KraftmineModBlocks.CHERRY_STAIRS, KraftmineModTabs.TAB_CRTAB);
	public static final Item CHERRY_SLAB = register(KraftmineModBlocks.CHERRY_SLAB, KraftmineModTabs.TAB_CRTAB);
	public static final Item CHERRY_FENCE_GATE = register(KraftmineModBlocks.CHERRY_FENCE_GATE, KraftmineModTabs.TAB_CRTAB);
	public static final Item CHERRY_BUTTON = register(KraftmineModBlocks.CHERRY_BUTTON, KraftmineModTabs.TAB_CRTAB);
	public static final Item PALM_WOOD_WOOD = register(KraftmineModBlocks.PALM_WOOD_WOOD, KraftmineModTabs.TAB_CRTAB);
	public static final Item PALM_WOOD_LOG = register(KraftmineModBlocks.PALM_WOOD_LOG, KraftmineModTabs.TAB_CRTAB);
	public static final Item PALM_WOOD_PLANKS = register(KraftmineModBlocks.PALM_WOOD_PLANKS, KraftmineModTabs.TAB_CRTAB);
	public static final Item PALM_WOOD_LEAVES = register(KraftmineModBlocks.PALM_WOOD_LEAVES, KraftmineModTabs.TAB_CRTAB);
	public static final Item PALM_WOOD_STAIRS = register(KraftmineModBlocks.PALM_WOOD_STAIRS, KraftmineModTabs.TAB_CRTAB);
	public static final Item PALM_WOOD_SLAB = register(KraftmineModBlocks.PALM_WOOD_SLAB, KraftmineModTabs.TAB_CRTAB);
	public static final Item PALM_WOOD_FENCE = register(KraftmineModBlocks.PALM_WOOD_FENCE, KraftmineModTabs.TAB_CRTAB);
	public static final Item PALM_WOOD_PRESSURE_PLATE = register(KraftmineModBlocks.PALM_WOOD_PRESSURE_PLATE, KraftmineModTabs.TAB_CRTAB);
	public static final Item PALM_WOOD_BUTTON = register(KraftmineModBlocks.PALM_WOOD_BUTTON, KraftmineModTabs.TAB_CRTAB);
	public static final Item BAMBOO_PLANKS = register(KraftmineModBlocks.BAMBOO_PLANKS, KraftmineModTabs.TAB_CRTAB);
	public static final Item BAMBOO_STAIRS = register(KraftmineModBlocks.BAMBOO_STAIRS, KraftmineModTabs.TAB_CRTAB);
	public static final Item BAMBOO_SLAB = register(KraftmineModBlocks.BAMBOO_SLAB, KraftmineModTabs.TAB_CRTAB);
	public static final Item BAMBOO_FENCE = register(KraftmineModBlocks.BAMBOO_FENCE, KraftmineModTabs.TAB_CRTAB);
	public static final Item BAMBOO_FENCE_GATE = register(KraftmineModBlocks.BAMBOO_FENCE_GATE, KraftmineModTabs.TAB_CRTAB);
	public static final Item BAMBOO_PRESSURE_PLATE = register(KraftmineModBlocks.BAMBOO_PRESSURE_PLATE, KraftmineModTabs.TAB_CRTAB);
	public static final Item BAMBOO_BUTTON = register(KraftmineModBlocks.BAMBOO_BUTTON, KraftmineModTabs.TAB_CRTAB);
	public static final Item CORN = register(new CornItem());
	public static final Item FOOD_MATERWELON = register(new FoodMaterwelonItem());
	public static final Item RANGED_TOMATO = register(new RangedTomatoItem());
	public static final Item CHERRY = register(new CherryItem());
	public static final Item APPLEBLOCK = register(KraftmineModBlocks.APPLEBLOCK, KraftmineModTabs.TAB_CRTAB);
	public static final Item TUNGSTEN_ORE = register(KraftmineModBlocks.TUNGSTEN_ORE, KraftmineModTabs.TAB_CRTAB);
	public static final Item TUNGSTEN_BLOCK = register(KraftmineModBlocks.TUNGSTEN_BLOCK, KraftmineModTabs.TAB_CRTAB);
	public static final Item CLOUD = register(KraftmineModBlocks.CLOUD, KraftmineModTabs.TAB_CRTAB);
	public static final Item CLOUD_BLOCK_RAIN = register(KraftmineModBlocks.CLOUD_BLOCK_RAIN, KraftmineModTabs.TAB_CRTAB);
	public static final Item LEGO_BLOCK = register(KraftmineModBlocks.LEGO_BLOCK, KraftmineModTabs.TAB_CRTAB);
	public static final Item WOOD_INGOT = register(new WoodIngotItem());
	public static final Item PEBBLE = register(new PebbleItem());
	public static final Item TUNGSTEN_PICKAXE = register(new TungstenPickaxeItem());
	public static final Item TUNGSTEN_AXE = register(new TungstenAxeItem());
	public static final Item TUNGSTEN_SWORD_0 = register(new TungstenSword0Item());
	public static final Item TUNGSTEN_SHOVEL = register(new TungstenShovelItem());
	public static final Item TUNGSTEN_HOE = register(new TungstenHoeItem());
	public static final Item TUNGSTEN_SWORD = register(new TungstenSwordItem());
	public static final Item HUSK_CLAW = register(new HuskClawItem());
	public static final Item OBSIDIAN_NUGGET = register(new ObsidianNuggetItem());
	public static final Item OBSIDIANSCRAP = register(new ObsidianscrapItem());
	public static final Item OBSIDIAN_ARMOR_HELMET = register(new ObsidianArmorItem.Helmet());
	public static final Item OBSIDIAN_ARMOR_CHESTPLATE = register(new ObsidianArmorItem.Chestplate());
	public static final Item OBSIDIAN_ARMOR_LEGGINGS = register(new ObsidianArmorItem.Leggings());
	public static final Item OBSIDIAN_ARMOR_BOOTS = register(new ObsidianArmorItem.Boots());
	public static final Item TUNGSTEN_ARMOR_HELMET = register(new TungstenArmorItem.Helmet());
	public static final Item TUNGSTEN_ARMOR_CHESTPLATE = register(new TungstenArmorItem.Chestplate());
	public static final Item TUNGSTEN_ARMOR_LEGGINGS = register(new TungstenArmorItem.Leggings());
	public static final Item TUNGSTEN_ARMOR_BOOTS = register(new TungstenArmorItem.Boots());
	public static final Item DRIP_ARMOR_HELMET = register(new DripArmorItem.Helmet());
	public static final Item DRIP_ARMOR_CHESTPLATE = register(new DripArmorItem.Chestplate());
	public static final Item DRIP_ARMOR_LEGGINGS = register(new DripArmorItem.Leggings());
	public static final Item DRIP_ARMOR_BOOTS = register(new DripArmorItem.Boots());
	public static final Item EYEPATCH_HELMET = register(new EyepatchItem.Helmet());
	public static final Item AETHER_DIMENSION = register(new AetherDimensionItem());
	public static final Item BAMBOO_PICKAXE = register(new BambooPickaxeItem());
	public static final Item BAMBOO_AXE = register(new BambooAxeItem());
	public static final Item BAMBOO_SWORD = register(new BambooSwordItem());
	public static final Item BAMBOO_SHOVEL = register(new BambooShovelItem());
	public static final Item BAMBOO_HOE = register(new BambooHoeItem());
	public static final Item REACTOR_CORE = register(new ReactorCoreItem());
	public static final Item REACTOR_CORE_LOW = register(new ReactorCoreLowItem());
	public static final Item FRYING_PAN = register(new FryingPanItem());
	public static final Item ENCHANTEDFLINTANDSTEEL = register(new EnchantedflintandsteelItem());
	public static final Item BLADE_RAZOR = register(new BladeRazorItem());
	public static final Item BLADE_OF_DESPAIR = register(new BladeOfDespairItem());
	public static final Item DIAMONDSABER = register(new DiamondsaberItem());
	public static final Item SABER_RED = register(new SaberRedItem());
	public static final Item SABER_GREEN = register(new SaberGreenItem());
	public static final Item SABER_PURPLE = register(new SaberPurpleItem());
	public static final Item SABER_WHITE = register(new SaberWhiteItem());
	public static final Item SABER_YELLOW = register(new SaberYellowItem());
	public static final Item SABER_ORANGE = register(new SaberOrangeItem());
	public static final Item SABER_DARK = register(new SaberDarkItem());
	public static final Item CRYSTALRED = register(new CrystalredItem());
	public static final Item CRYSTAL_GREEN = register(new CrystalGreenItem());
	public static final Item CRYSTAL_PURPLE = register(new CrystalPurpleItem());
	public static final Item CRYSTAL_YELLOW = register(new CrystalYellowItem());
	public static final Item CRYSTAL_ORANGE = register(new CrystalOrangeItem());
	public static final Item CRYSTAL_BLUE = register(new CrystalBlueItem());
	public static final Item CRYSTAL_WHITE = register(new CrystalWhiteItem());
	public static final Item CRYSTAL_DARK = register(new CrystalDarkItem());
	public static final Item GOOSE = register(
			new SpawnEggItem(KraftmineModEntities.GOOSE, -9421005, -1, new Item.Properties().tab(KraftmineModTabs.TAB_CRTAB))
					.setRegistryName("goose_spawn_egg"));
	public static final Item GHOST_SPIDER = register(
			new SpawnEggItem(KraftmineModEntities.GHOST_SPIDER, -7763575, -5776683, new Item.Properties().tab(KraftmineModTabs.TAB_CRTAB))
					.setRegistryName("ghost_spider_spawn_egg"));
	public static final Item MIMIC_ENTITY = register(
			new SpawnEggItem(KraftmineModEntities.MIMIC_ENTITY, -3381760, -10066330, new Item.Properties().tab(KraftmineModTabs.TAB_CRTAB))
					.setRegistryName("mimic_entity_spawn_egg"));
	public static final Item MICKEY = register(
			new SpawnEggItem(KraftmineModEntities.MICKEY, -16777216, -65536, new Item.Properties().tab(KraftmineModTabs.TAB_CRTAB))
					.setRegistryName("mickey_spawn_egg"));
	public static final Item MOB_AMOGUS = register(
			new SpawnEggItem(KraftmineModEntities.MOB_AMOGUS, -3407872, -6710887, new Item.Properties().tab(KraftmineModTabs.TAB_CRTAB))
					.setRegistryName("mob_amogus_spawn_egg"));
	public static final Item SIRENHEAD = register(
			new SpawnEggItem(KraftmineModEntities.SIRENHEAD, -12384248, -12970217, new Item.Properties().tab(KraftmineModTabs.TAB_CRTAB))
					.setRegistryName("sirenhead_spawn_egg"));
	public static final Item GIANT_AI = register(
			new SpawnEggItem(KraftmineModEntities.GIANT_AI, -16738048, -10092544, new Item.Properties().tab(KraftmineModTabs.TAB_CRTAB))
					.setRegistryName("giant_ai_spawn_egg"));
	public static final Item TUNGSTEN_INGOT = register(new TungstenIngotItem());
	public static final Item CHERRY_FENCE = register(KraftmineModBlocks.CHERRY_FENCE, CreativeModeTab.TAB_DECORATIONS);
	public static final Item CHERRY_PRESSURE_PLATE = register(KraftmineModBlocks.CHERRY_PRESSURE_PLATE, CreativeModeTab.TAB_REDSTONE);
	public static final Item PALM_WOOD_FENCE_GATE = register(KraftmineModBlocks.PALM_WOOD_FENCE_GATE, CreativeModeTab.TAB_REDSTONE);
	public static final Item WATER_CUP = register(new WaterCupItem());
	public static final Item WOODEN_CUP = register(new WoodenCupItem());
	public static final Item WINE_GLASS = register(new WineGlassItem());
	public static final Item WATER_CUP_GLASS = register(new WaterCupGlassItem());
	public static final Item WATER_CUP_MUG = register(new WaterCupMugItem());
	public static final Item MUG = register(new MugItem());
	public static final Item WATER_GOLD = register(new WaterGoldItem());
	public static final Item CHALICE = register(new ChaliceItem());
	public static final Item WALLNUT = register(KraftmineModBlocks.WALLNUT, KraftmineModTabs.TAB_CRTAB);

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	private static Item register(Block block, CreativeModeTab tab) {
		return register(new BlockItem(block, new Item.Properties().tab(tab)).setRegistryName(block.getRegistryName()));
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
