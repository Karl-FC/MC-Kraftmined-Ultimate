
package net.mcreator.kraftmine.item;

import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.InteractionResult;

import net.mcreator.kraftmine.procedures.ChaliceCupRightClickProcedure;
import net.mcreator.kraftmine.init.KraftmineModTabs;

public class ChaliceItem extends Item {
	public ChaliceItem() {
		super(new Item.Properties().tab(KraftmineModTabs.TAB_CRTAB).stacksTo(1).rarity(Rarity.COMMON));
		setRegistryName("chalice");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		InteractionResult retval = super.useOn(context);
		ChaliceCupRightClickProcedure.execute(context.getLevel().getBlockState(context.getClickedPos()), context.getPlayer());
		return retval;
	}
}
